package org.chobit.spring;

public class MyApp {


    public static void main(String[] args) {
        String s = "2020-03-11 12:59:07";
        System.out.println();
    }

}
