package org.chobit.spring.component;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.chobit.kafka.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicBoolean;

@Component("zhyyy")
public class MyProcessor implements Processor<String, String> {

    private static final Logger logger = LoggerFactory.getLogger("all");

    private static final long start = System.currentTimeMillis();

    private static final AtomicBoolean flag = new AtomicBoolean(true);

    @Override
    public void process(ConsumerRecords<String, String> records) {

        for (ConsumerRecord<String, String> r : records) {
            System.out.println(r.value());
            logger.info(r.value());
        }
    }

}
